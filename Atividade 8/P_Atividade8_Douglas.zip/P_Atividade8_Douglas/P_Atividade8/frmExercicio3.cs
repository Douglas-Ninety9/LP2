﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace P_Atividade8
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            int[] Quantidade = new int[10];
            double[] Preco = new double[10];
            string Auxiliar = "";
            double TotalMensal = 0;
            int i = 0;
            
            for (i = 0; i < Preco.Length; i++) 
            {
                do
                {
                    Auxiliar = Interaction.InputBox("Digite a quantidade de Mercadoria \n ' Código ': " +
                        (i + 1).ToString(), "Entrada de Dados");

                    if (Auxiliar == "")
                        break;

                    if (!int.TryParse(Auxiliar, out Quantidade[i]))
                    {
                        MessageBox.Show("Número inválido!");
                    }
                } while (!(Quantidade[i] > 0));

                Auxiliar = "";
                do
                {
                    Auxiliar = Interaction.InputBox("Digite o Preço R$ da Mercadoria \n ' Código ': " +
                        (i + 1).ToString(), "Entrada de Dados");

                    if (Auxiliar == "")
                        break;

                    if (!double.TryParse(Auxiliar, out Preco[i]))
                    {
                        MessageBox.Show("Dado inválido!");
                    }
                } while (!(Preco[i] > 0));
            }

            for (i = 0; i < Quantidade.Length; i++)
            {
                TotalMensal += Quantidade[i] * Preco[i];
            }

            MessageBox.Show("O Valor Total Mensal é: " + TotalMensal.ToString("C2"));
            
        
            
        }

    }
}
