﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P_Atividade8
{
    public partial class frmExercicio6 : Form
    {
        public frmExercicio6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[,] NotaAlunos = new double[2,3];
            double[] Media = new double[2];
            string Auxiliar = "";
            string AuxMedia = "";

            for (var x = 0; x < 2; x++)
            {
                for (var y = 0; y < 3; y++)
                {

                    Auxiliar = Interaction.InputBox("Digite a: " + (y + 1).ToString() + "\n"
                                            + "Nota do Aluno: " + (x + 1).ToString(), "Entrada de dados");
                    NotaAlunos[x, y] = Convert.ToDouble(Auxiliar);
                    Auxiliar = "";
                }
            }

            for (var i = 0; i < 2; i++)
            {
                Media[i] = (NotaAlunos[i, 0] + NotaAlunos[i, 1] + NotaAlunos[i, 2]) / 3;
                AuxMedia += "\n" + "Aluno " + (i + 1).ToString() + " Média: " + Media[i].ToString();
            }
                    MessageBox.Show( AuxMedia);






        }
    }
}
