﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P_Atividade8
{
    public partial class frmExercicio7 : Form
    {
        public frmExercicio7()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

                string Dados = "";
                string[] VetNomes = new string[1];
                for (var i = 0; i < 1; i++)

                {              
                    Dados = Interaction.InputBox("Digite o nome completo da " + (i + 1).ToString() + " pessoa: ", "Entrada de Dados: ");
                    VetNomes[i] = Dados;
                    Dados = "";
                }

                for (var i = 0; i < 1; i++)
                {
                    Dados = VetNomes[i].Trim().Replace(" ", "");
                    ListaNomesEQuantidadeDeCaracters.Items.Add("\n O nome: " + VetNomes[i] + " tem " + Dados.Length + " caracteres. ");
                    Dados = "";
                }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnApagar_Click(object sender, EventArgs e)
        {
            ListaNomesEQuantidadeDeCaracters.Items.Clear();
        }
    }
}
