﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P_Atividade8
{
    public partial class frmExercício1 : Form
    {
        public frmExercício1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            
            for (var i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Entre com Número" + (i + 1).ToString(),"Entrada de Dados") ;

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
            }
            auxiliar = "";
            for (var i = vetor.Length - 1; i >= 0; i--)
                auxiliar += "\n" + vetor[i]; // OU auxiliar = auxiliar "\n" + vetor[i];

            MessageBox.Show(auxiliar);
        }
        private void bntExtra_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string Saida = "";

            for (var i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Entre com Número" + (i + 1).ToString(), "Entrada de Dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
                else
                {
                    Saida = auxiliar[i] + "\n" + Saida;
                }
            }
            MessageBox.Show(Saida);
        }
    }
}
