﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;


namespace P_Atividade8
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {


            List<string> Nomes = new List<string>(new string [] { "Ana", "André", "Débora", "Fátima", "João",
                                                    "Janete", "Otávio", "Marcelo", "Pedro", "Thais" }) ;

            Nomes.Remove("Otávio");

            foreach (string elemento in Nomes)
            {
                MessageBox.Show("Lista de Nomes:" + elemento.ToString());

            }
        


        }
    }
}
