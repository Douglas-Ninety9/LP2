﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos_Douglas
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }
        private void BtnQtdCaracter_Click(object sender, EventArgs e)
        {
          int Total = rctxtTexto.Text.Length;
          int Cont, QtdeCaracter = 0;
          string Texto = rctxtTexto.Text;

            for (Cont = 0; Cont < Total; Cont++)
            {
                var c = Texto[Cont];
                if (char.IsNumber(c))
                {
                    QtdeCaracter++;
                }
            }
            MessageBox.Show("A quantidade de caracteres numéricos do texto é:" + QtdeCaracter);
        }

        private void btnprmCaracterBranco_Click(object sender, EventArgs e)
        {
            int posicaoCaracter = 1, cont = 0;
            string Texto = rctxtTexto.Text;


            while (cont <= rctxtTexto.Text.Length)
            {
                var x = Texto[cont];
                if (char.IsWhiteSpace(x))
                {
                    break;
                }
                else
                {
                    posicaoCaracter++;
                }
                cont++;
            }
            MessageBox.Show("A Posição do 1° espaço em branco é: " + posicaoCaracter);
        }

        private void btnCaracterAlfabetico_Click(object sender, EventArgs e)
        {
            int caracterTotal = rctxtTexto.Text.Length;
            int QtdeCaracter = 0;
            string Texto = rctxtTexto.Text;


            for (int i = 0; i < Texto.Length; i++)
            {
                char c = Texto[i];
                if (Char.IsLetter(c))
                {
                    QtdeCaracter++;
                }

            }
            MessageBox.Show("A quantidade de caracteres alfabéticos no texto são: " + QtdeCaracter);
        }

        private void btnApagar_Click(object sender, EventArgs e)
        {
            rctxtTexto.Clear();
        }
    }
    
}
