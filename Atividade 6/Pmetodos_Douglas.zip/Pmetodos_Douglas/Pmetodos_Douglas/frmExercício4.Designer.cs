﻿
namespace Pmetodos_Douglas
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rctxtTexto = new System.Windows.Forms.RichTextBox();
            this.BtnQtdCaracter = new System.Windows.Forms.Button();
            this.btnprmCaracterBranco = new System.Windows.Forms.Button();
            this.btnCaracterAlfabetico = new System.Windows.Forms.Button();
            this.btnApagar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rctxtTexto
            // 
            this.rctxtTexto.Location = new System.Drawing.Point(13, 61);
            this.rctxtTexto.Margin = new System.Windows.Forms.Padding(4);
            this.rctxtTexto.Name = "rctxtTexto";
            this.rctxtTexto.Size = new System.Drawing.Size(715, 150);
            this.rctxtTexto.TabIndex = 0;
            this.rctxtTexto.Text = "";
            // 
            // BtnQtdCaracter
            // 
            this.BtnQtdCaracter.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnQtdCaracter.Location = new System.Drawing.Point(13, 260);
            this.BtnQtdCaracter.Margin = new System.Windows.Forms.Padding(4);
            this.BtnQtdCaracter.Name = "BtnQtdCaracter";
            this.BtnQtdCaracter.Size = new System.Drawing.Size(276, 103);
            this.BtnQtdCaracter.TabIndex = 1;
            this.BtnQtdCaracter.Text = "Quantidade de Caracteres numéricos";
            this.BtnQtdCaracter.UseVisualStyleBackColor = true;
            this.BtnQtdCaracter.Click += new System.EventHandler(this.BtnQtdCaracter_Click);
            // 
            // btnprmCaracterBranco
            // 
            this.btnprmCaracterBranco.Location = new System.Drawing.Point(324, 260);
            this.btnprmCaracterBranco.Margin = new System.Windows.Forms.Padding(4);
            this.btnprmCaracterBranco.Name = "btnprmCaracterBranco";
            this.btnprmCaracterBranco.Size = new System.Drawing.Size(276, 105);
            this.btnprmCaracterBranco.TabIndex = 2;
            this.btnprmCaracterBranco.Text = "Retorna primeiro caracter Branco e sua posição";
            this.btnprmCaracterBranco.UseVisualStyleBackColor = true;
            this.btnprmCaracterBranco.Click += new System.EventHandler(this.btnprmCaracterBranco_Click);
            // 
            // btnCaracterAlfabetico
            // 
            this.btnCaracterAlfabetico.Location = new System.Drawing.Point(637, 258);
            this.btnCaracterAlfabetico.Margin = new System.Windows.Forms.Padding(4);
            this.btnCaracterAlfabetico.Name = "btnCaracterAlfabetico";
            this.btnCaracterAlfabetico.Size = new System.Drawing.Size(276, 105);
            this.btnCaracterAlfabetico.TabIndex = 3;
            this.btnCaracterAlfabetico.Text = "Quantidade de caracter Alfabético";
            this.btnCaracterAlfabetico.UseVisualStyleBackColor = true;
            this.btnCaracterAlfabetico.Click += new System.EventHandler(this.btnCaracterAlfabetico_Click);
            // 
            // btnApagar
            // 
            this.btnApagar.Location = new System.Drawing.Point(780, 61);
            this.btnApagar.Name = "btnApagar";
            this.btnApagar.Size = new System.Drawing.Size(133, 150);
            this.btnApagar.TabIndex = 4;
            this.btnApagar.Text = "Apagar";
            this.btnApagar.UseVisualStyleBackColor = true;
            this.btnApagar.Click += new System.EventHandler(this.btnApagar_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(933, 517);
            this.Controls.Add(this.btnApagar);
            this.Controls.Add(this.btnCaracterAlfabetico);
            this.Controls.Add(this.btnprmCaracterBranco);
            this.Controls.Add(this.BtnQtdCaracter);
            this.Controls.Add(this.rctxtTexto);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmExercicio4";
            this.Text = "frmExercício4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rctxtTexto;
        private System.Windows.Forms.Button BtnQtdCaracter;
        private System.Windows.Forms.Button btnprmCaracterBranco;
        private System.Windows.Forms.Button btnCaracterAlfabetico;
        private System.Windows.Forms.Button btnApagar;
    }
}