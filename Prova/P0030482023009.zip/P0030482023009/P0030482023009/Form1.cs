﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace P0030482023009
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[,] arrayValores = new double[9, 4];
            double[] VetTotalMes = new double[9];
            string Auxiliar;
            double TotMeses = 0;

            for (int i = 0; i < 9; i++)
            {
                for (int x = 0; x < 4; x++)
                {
                    Auxiliar = Interaction.InputBox("Digite o valor da semana " + (x + 1) + " Do Mês: " + 
                                                                               (i + 1), "Entrada de dados");
                    if (Auxiliar == "")
                    {
                        MessageBox.Show("Campo está vazio");
                        x--;
                    }
                    else if (double.TryParse(Auxiliar, out arrayValores[i, x]))
                    {
                        double.TryParse(Auxiliar, out arrayValores[i, x]);
                    }
                    else
                    {
                        MessageBox.Show("Digite apenas números!");
                        x--;
                    }
                }
            }
            for (int i = 0; i < 9; i++)
            {
                for (int x = 0; x < 4; x++)
                {
                    VetTotalMes[i] = VetTotalMes[i] + arrayValores[i, x];
                }
                TotMeses = TotMeses + VetTotalMes[i];
            }
            for (int i = 0; i < 9; i++)
            {
                for (int x = 0; x < 4; x++)
                {
                    listBoxDados.Items.Add("Total do Mês: " + (i + 1).ToString() +
                                    " Semana: " + (x + 1).ToString() + " " +arrayValores[i, x].ToString("C2"));
                }
                listBoxDados.Items.Add(">>Total Mês: " + VetTotalMes[i].ToString("C2"));
                listBoxDados.Items.Add("...............................");
            }
            listBoxDados.Items.Add("Total Geral: R$" + TotMeses.ToString ("C2"));
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnApagar_Click(object sender, EventArgs e)
        {
            listBoxDados.Items.Clear();
        }
    }
}
