﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P_Atividade7_Douglas
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtNum.Clear();
        }

        private void btnGerar_Click(object sender, EventArgs e)
        {
            double Cont;
            double NumH = 0, NumN;

            for (Cont = 1; Cont <= Convert.ToDouble(txtNum.Text); Cont++)
            { 
                if (Convert.ToDouble(txtNum.Text) > 0)
                {
                    NumN = 1 / Cont;
                    NumH = NumH + NumN;
                }
            }
            MessageBox.Show("O Número gerado é:" + NumH);
        }
    }
}
