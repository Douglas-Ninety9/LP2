﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P_Atividade7_Douglas
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void bntEspaçoEmBranco_Click(object sender, EventArgs e)
        {
            string Texto = rchTxt1.Text;
            int Cont , QtdCaracteres = 0;
            {
                for (Cont = 0; Cont < rchTxt1.Text.Length; Cont ++)
                {
                    var x = Texto[Cont];
                    if (char.IsWhiteSpace(x))
                    {
                        QtdCaracteres++;
                    }
                }
                MessageBox.Show("O número de espaços em branco é: " + QtdCaracteres);
            }
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            string Frase = rchTxt1.Text;
            int Cont = 0, QtdCaracteres = 0;

            while (Cont < rchTxt1.Text.Length)
            {
                if (Frase[Cont] == 'R' || Frase[Cont] == 'r')
                {
                    QtdCaracteres++;
                }
                Cont++;
            }

            MessageBox.Show("A quantidade de letras r é: " + QtdCaracteres);

        }

        private void btnParDeLetras_Click(object sender, EventArgs e)
        {
            //string Par = rchTxt1.Text;
            //int Cont = 0, QtdParLetras =0;

            //for (Cont = 0; Cont > rchTxt1.Text.Length; Cont++)
            //{

            //}
            int QtdParLetras = 0, Cont;
            char Par = ' ';
            string Texto = rchTxt1.Text;

            for (Cont = 0; Cont < rchTxt1.Text.Length; Cont++)
            {
                if (Par == Texto[Cont])
                {
                    QtdParLetras++;
                }
                Par = Texto[Cont];
            }
            MessageBox.Show("Quantidade de Caracter Duplo é: " + QtdParLetras);
        }
    }
    
}
