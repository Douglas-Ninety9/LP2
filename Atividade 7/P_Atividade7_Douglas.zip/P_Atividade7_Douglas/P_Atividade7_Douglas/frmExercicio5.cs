﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P_Atividade7_Douglas
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            string Nome = txtNome.Text;
            string Cargo = txtCargo.Text;
            string Inscrição = txtNumInscricao.Text;

            double Salario = Convert.ToDouble(maskedSalario.Text);
            double Gratificacao = Convert.ToDouble(maskedGratificacao.Text);
            double SalarioBruto, A;

            int Producao = Convert.ToInt32(maskedProducao.Text);
            int B, C, D;

            if (Producao >= 100)
            {
                B = 1;
            }
            else
            {
                B = 0;
            }
            if (Producao >= 120)
            {
                C = 1;
            }
            else
            {
                C = 0;
            }
            if (Producao >= 150)
            {
                D = 1;
            }
            else
            {
                D = 0;
            }

            A = Salario;

            if (A <= 7000)
            {
                SalarioBruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + Gratificacao;
            }
            else
            {
                SalarioBruto = A;
            }
            if (SalarioBruto > 7000 && Producao >=150 && Gratificacao >0 )  
                {
                    SalarioBruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + Gratificacao;
                }
                else
                {
                    SalarioBruto = A;
                }       
            MessageBox.Show ("Nome:" + txtNome );
            MessageBox.Show ("Cargo:" + txtCargo);
            MessageBox.Show ("Inscrição:" + txtNumInscricao);
            MessageBox.Show (" Produção:" + maskedProducao);
            MessageBox.Show (" Salário:" + maskedSalario);
            MessageBox.Show ("Gratificação:" + maskedGratificacao); 
            MessageBox.Show (" Salário Bruto:" + SalarioBruto);
        }
        private void btnApagar_Click(object sender, EventArgs e)
        {
            maskedSalario.Clear();
            maskedProducao.Clear();
            maskedGratificacao.Clear();
            txtNome.Text = string.Empty;
            txtCargo.Text = string.Empty;
            txtNumInscricao.Text = string.Empty;
        }
    }
}
