﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P_Atividade7_Douglas
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnApagar_Click(object sender, EventArgs e)
        {
            txtFrase.Text = String.Empty;
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {

            string Texto = txtFrase.Text.Trim();
            string TextoInvertido = "";
            char[] x = Texto.ToCharArray();
            
                Array.Reverse(x);
                
                foreach (char c in x)
                {
                    TextoInvertido = TextoInvertido + c.ToString();
                }
            Texto = Texto.ToUpper().Trim();
            TextoInvertido = TextoInvertido.ToUpper().Trim();
            if (string.Equals(Texto, TextoInvertido))
            {
                MessageBox.Show("Esta frase é um Palíndromo !" + TextoInvertido);
            }
            else
            {
                MessageBox.Show("Esta frase não é um Palíndromo !" + TextoInvertido);
            }


        }
    }
}
