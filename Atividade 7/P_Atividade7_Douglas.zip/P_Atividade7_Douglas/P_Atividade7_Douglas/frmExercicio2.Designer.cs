﻿
namespace P_Atividade7_Douglas
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchTxt1 = new System.Windows.Forms.RichTextBox();
            this.bntEspaçoEmBranco = new System.Windows.Forms.Button();
            this.btnLetraR = new System.Windows.Forms.Button();
            this.btnParDeLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchTxt1
            // 
            this.rchTxt1.Location = new System.Drawing.Point(37, 75);
            this.rchTxt1.Margin = new System.Windows.Forms.Padding(4);
            this.rchTxt1.Name = "rchTxt1";
            this.rchTxt1.Size = new System.Drawing.Size(983, 164);
            this.rchTxt1.TabIndex = 0;
            this.rchTxt1.Text = "";
            // 
            // bntEspaçoEmBranco
            // 
            this.bntEspaçoEmBranco.Location = new System.Drawing.Point(37, 296);
            this.bntEspaçoEmBranco.Margin = new System.Windows.Forms.Padding(4);
            this.bntEspaçoEmBranco.Name = "bntEspaçoEmBranco";
            this.bntEspaçoEmBranco.Size = new System.Drawing.Size(307, 117);
            this.bntEspaçoEmBranco.TabIndex = 1;
            this.bntEspaçoEmBranco.Text = "Número de espaços em branco existentes";
            this.bntEspaçoEmBranco.UseVisualStyleBackColor = true;
            this.bntEspaçoEmBranco.Click += new System.EventHandler(this.bntEspaçoEmBranco_Click);
            // 
            // btnLetraR
            // 
            this.btnLetraR.Location = new System.Drawing.Point(377, 295);
            this.btnLetraR.Margin = new System.Windows.Forms.Padding(4);
            this.btnLetraR.Name = "btnLetraR";
            this.btnLetraR.Size = new System.Drawing.Size(307, 117);
            this.btnLetraR.TabIndex = 2;
            this.btnLetraR.Text = "Número de vezes que aparece a letra \"R\"";
            this.btnLetraR.UseVisualStyleBackColor = true;
            this.btnLetraR.Click += new System.EventHandler(this.btnLetraR_Click);
            // 
            // btnParDeLetras
            // 
            this.btnParDeLetras.Location = new System.Drawing.Point(714, 295);
            this.btnParDeLetras.Margin = new System.Windows.Forms.Padding(4);
            this.btnParDeLetras.Name = "btnParDeLetras";
            this.btnParDeLetras.Size = new System.Drawing.Size(307, 117);
            this.btnParDeLetras.TabIndex = 3;
            this.btnParDeLetras.Text = "Número de vezes que ocorre o mesmo par de letras";
            this.btnParDeLetras.UseVisualStyleBackColor = true;
            this.btnParDeLetras.Click += new System.EventHandler(this.btnParDeLetras_Click);
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 509);
            this.Controls.Add(this.btnParDeLetras);
            this.Controls.Add(this.btnLetraR);
            this.Controls.Add(this.bntEspaçoEmBranco);
            this.Controls.Add(this.rchTxt1);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmExercicio2";
            this.Text = "Exercício2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchTxt1;
        private System.Windows.Forms.Button bntEspaçoEmBranco;
        private System.Windows.Forms.Button btnLetraR;
        private System.Windows.Forms.Button btnParDeLetras;
    }
}