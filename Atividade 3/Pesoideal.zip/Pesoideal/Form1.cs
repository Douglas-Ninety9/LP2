﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ppesoideal
{
    public partial class Form1 : Form
    {
        double PesoAT, PesoID, Altura;

        private void button2_Click(object sender, EventArgs e)
        {
            maskedTextBox1.Clear();
            maskedTextBox2.Clear();
            textBox1.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (double.TryParse(maskedTextBox1.Text, out Altura) && double.TryParse(maskedTextBox2.Text, out PesoAT))
            {
                if (Altura != 0 && PesoAT != 0)
                {
                    PesoAT = Math.Round(PesoAT, 1);
                    if (double.TryParse(maskedTextBox1.Text, out Altura) && ButtonMasc.Checked)
                    {
                        PesoID = (72.7 * Altura) - 58;
                        PesoID = Math.Round(PesoID, 1);
                        textBox1.Text = PesoID.ToString();

                        if (PesoAT > PesoID)
                        {
                            MessageBox.Show("Você está acima do peso, por favor faça exercícios");
                        }
                        else if (PesoAT < PesoID)
                        {
                            MessageBox.Show("Você está abaixo do peso ideal, por favor se alimente!");
                        }
                        else
                        {
                            MessageBox.Show("Você está no peso ideal");
                        }
                    }
                    else if (double.TryParse(maskedTextBox1.Text, out Altura) 
                        && double.TryParse(maskedTextBox2.Text, out PesoAT) && ButtonFem.Checked)
                    {
                        PesoID = (62.1 * Altura) - 44.7;
                        PesoID = Math.Round(PesoID, 1);
                        textBox1.Text = PesoID.ToString();

                        if (PesoAT > PesoID)
                        {
                            MessageBox.Show("Você está acima do peso, por favor faça exercícios");
                        }
                        else if (PesoAT < PesoID)
                        {
                            MessageBox.Show("Você está abaixo do peso ideal, por favor se alimente!");
                        }
                        else
                        {
                            MessageBox.Show("Você está no peso ideal");
                        }

                    }
                    else
                    {
                        MessageBox.Show("Valores ou marcações incorretas, verifique!");
                    }
                }
                else
                {
                    MessageBox.Show("Não pode usar o valor 0, digite outro número!");
                }
            }
            else
            {
                MessageBox.Show("Valores incorretos, verifique!");
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
