﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace P_Classes_Douglas
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Criando o objeto e instânciando o objeto
            Horista objHorista = new Horista();

            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalario.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtHoras.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtFaltas.Text);

            //get, Imprime os Valores do objeto.
            MessageBox.Show("Nome : " + objHorista.NomeEmpregado + "\n"+
                             "Matrícula : " + objHorista.Matricula + "\n"+
                             "Tempo Trabalho: " + objHorista.TempoTrabalho().ToString() + "\n"+
                             "Salário: " + objHorista.SalarioBruto().ToString("N2"));


        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
