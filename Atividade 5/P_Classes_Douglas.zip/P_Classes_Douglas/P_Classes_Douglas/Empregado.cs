﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P_Classes_Douglas
{
    abstract class Empregado
    {

        private int matricula; // Atributo
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;

        public int Matricula // propriedade
        {
         get { return matricula; }
         set { matricula = value; }
        }

        public string NomeEmpregado
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }

        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }
        // Método são ações / comportamento
        // Virtual --> Pode ser sobreescrito
        public virtual int TempoTrabalho() //Método
        {
        // Representa um intervalo de tempo
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa);

            return (span.Days);
        }
        //Deve ser implementado 
        //Drived classes must implement this.
        public abstract double SalarioBruto(); // Método
    }
}
