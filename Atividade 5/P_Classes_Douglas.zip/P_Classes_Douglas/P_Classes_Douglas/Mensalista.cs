﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P_Classes_Douglas
{
    class Mensalista : Empregado
    {
        public Mensalista()
        {

        }
        //Sobre carga - uma nova versão
        public Mensalista(int matx, string nomex, DateTime datax, double salariox)
        {
            Matricula = matx;
            NomeEmpregado = nomex;
            DataEntradaEmpresa = datax;
            SalarioMensal = salariox;
        }
         
        public double SalarioMensal { get; set; }
        // sobreescrevendo o método

        public override double SalarioBruto()
        {
            return SalarioMensal;
        }
    }
}
