﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        double Num1, Num2, Resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonMenos_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txt1.Text, out Num1) && double.TryParse(txt2.Text, out Num2))
            {
                Resultado = Num1 - Num2;
                txt3.Text = Resultado.ToString();
            }
        }

        private void buttonMultp_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txt1.Text, out Num1) && double.TryParse(txt2.Text, out Num2))
            {
                Resultado = Num1 * Num2;
                txt3.Text = Resultado.ToString();
            }
        }

        private void buttonDiv_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txt1.Text, out Num1) && double.TryParse(txt2.Text, out Num2))
            {
                if (Num2 == 0)
                {
                    MessageBox.Show("Não se pode dividir por 0! ");
                }
                else
                {
                    Resultado = Num1 / Num2;
                    txt3.Text = Resultado.ToString();
                }
            }
            else
            {
                MessageBox.Show("Números Inválidos! ");
            }
        }

        private void buttonSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonLimp_Click(object sender, EventArgs e)
        {
            txt1.Text = "";
            txt2.Clear();
            txt3.Text = String.Empty;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txt1.Text, out Num1) && double.TryParse(txt2.Text, out Num2))
            {
                Resultado = Num1 + Num2;
                txt3.Text = Resultado.ToString();
            }
        }
    }
}
