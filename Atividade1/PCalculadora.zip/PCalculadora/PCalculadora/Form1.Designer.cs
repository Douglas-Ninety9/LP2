﻿
namespace PCalculadora
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt1 = new System.Windows.Forms.TextBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.txt3 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BDiv = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.BAdd = new System.Windows.Forms.Button();
            this.BSub = new System.Windows.Forms.Button();
            this.BMult = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(247, 63);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(278, 34);
            this.txt1.TabIndex = 0;
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(247, 126);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(278, 34);
            this.txt2.TabIndex = 1;
            // 
            // txt3
            // 
            this.txt3.Location = new System.Drawing.Point(247, 205);
            this.txt3.Name = "txt3";
            this.txt3.Size = new System.Drawing.Size(278, 34);
            this.txt3.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(68, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 27);
            this.label1.TabIndex = 3;
            this.label1.Text = "Número 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(68, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 27);
            this.label2.TabIndex = 4;
            this.label2.Text = "Número 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(68, 206);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 27);
            this.label3.TabIndex = 5;
            this.label3.Text = "Resultado";
            // 
            // BDiv
            // 
            this.BDiv.BackColor = System.Drawing.SystemColors.ControlText;
            this.BDiv.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BDiv.Location = new System.Drawing.Point(580, 307);
            this.BDiv.Name = "BDiv";
            this.BDiv.Size = new System.Drawing.Size(159, 87);
            this.BDiv.TabIndex = 9;
            this.BDiv.Text = "/";
            this.BDiv.UseVisualStyleBackColor = false;
            this.BDiv.Click += new System.EventHandler(this.BDiv_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.ControlText;
            this.button5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button5.Location = new System.Drawing.Point(570, 185);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(169, 66);
            this.button5.TabIndex = 10;
            this.button5.Text = "Apagar";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // BAdd
            // 
            this.BAdd.BackColor = System.Drawing.SystemColors.ControlText;
            this.BAdd.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BAdd.Location = new System.Drawing.Point(60, 307);
            this.BAdd.Name = "BAdd";
            this.BAdd.Size = new System.Drawing.Size(159, 87);
            this.BAdd.TabIndex = 6;
            this.BAdd.Text = "+";
            this.BAdd.UseVisualStyleBackColor = false;
            this.BAdd.Click += new System.EventHandler(this.BAdd_Click);
            // 
            // BSub
            // 
            this.BSub.BackColor = System.Drawing.SystemColors.ControlText;
            this.BSub.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BSub.Location = new System.Drawing.Point(239, 307);
            this.BSub.Name = "BSub";
            this.BSub.Size = new System.Drawing.Size(159, 87);
            this.BSub.TabIndex = 7;
            this.BSub.Text = "-";
            this.BSub.UseVisualStyleBackColor = false;
            this.BSub.Click += new System.EventHandler(this.BSub_Click);
            // 
            // BMult
            // 
            this.BMult.BackColor = System.Drawing.SystemColors.ControlText;
            this.BMult.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BMult.Location = new System.Drawing.Point(404, 307);
            this.BMult.Name = "BMult";
            this.BMult.Size = new System.Drawing.Size(159, 87);
            this.BMult.TabIndex = 8;
            this.BMult.Text = "*";
            this.BMult.UseVisualStyleBackColor = false;
            this.BMult.Click += new System.EventHandler(this.BMult_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.ControlText;
            this.button6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button6.Location = new System.Drawing.Point(570, 43);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(169, 66);
            this.button6.TabIndex = 11;
            this.button6.Text = "Sair";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 27F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(975, 446);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.BDiv);
            this.Controls.Add(this.BMult);
            this.Controls.Add(this.BSub);
            this.Controls.Add(this.BAdd);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt3);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.txt1);
            this.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Form1";
            this.Text = "Form1";
            this.TransparencyKey = System.Drawing.Color.DarkSlateBlue;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.TextBox txt3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button BDiv;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button BAdd;
        private System.Windows.Forms.Button BSub;
        private System.Windows.Forms.Button BMult;
        private System.Windows.Forms.Button button6;
    }
}

