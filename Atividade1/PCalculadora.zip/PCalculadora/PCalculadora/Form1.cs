﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        double Numb1, Numb2, Result;
        public Form1()
        {
            InitializeComponent();
        }
        private void BMult_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txt1.Text, out Numb1) && double.TryParse(txt2.Text, out Numb2))
            {
                Result = Numb1 * Numb2;
                txt3.Text = Result.ToString();
            }

        }
        private void BDiv_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txt1.Text, out Numb1) && double.TryParse(txt2.Text, out Numb2))
            {
                if (Numb2 == 0)
                {
                    MessageBox.Show("Não se pode dividir por 0! ");
                }
                else
                {
                    Result = Numb1 / Numb2;
                    txt3.Text = Result.ToString();
                }
            }
            else
            {
                MessageBox.Show("Números Inválidos! ");
            }

        }

        private void BSub_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txt1.Text, out Numb1) && double.TryParse(txt2.Text, out Numb2))
            {
                Result = Numb1 - Numb2;
                txt3.Text = Result.ToString();
            }

        }

        private void BAdd_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txt1.Text, out Numb1) && double.TryParse(txt2.Text, out Numb2))
            {
                Result = Numb1 + Numb2;
                txt3.Text = Result.ToString();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            txt1.Text = "";
            txt2.Clear();
            txt3.Text = String.Empty;
        }
        private void button6_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
